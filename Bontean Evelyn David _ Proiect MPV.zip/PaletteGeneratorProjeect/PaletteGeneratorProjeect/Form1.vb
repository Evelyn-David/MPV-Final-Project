﻿Public Class Form1

    'Functii schimbare culori ============================================================================================================
    Function schimbaCuloare1(ByVal culoare As Object) As Double

        'Scimbare UI
        AvatarName.ForeColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        header.ForeColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        facebook.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        btn_filled.ForeColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))

        'Schimbare paleta
        paleta1.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        RGB1.Text = "(" + CStr(culoare(0)) + ", " + CStr(culoare(1)) + ", " + CStr(culoare(2)) + ")"
        Return (culoare(0))
    End Function

    Function schimbaCuloare2(ByVal culoare As Object) As Double
        'Scimbare UI
        btn_empty.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        twitter.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))

        'Schimbare paleta
        paleta2.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        RGB2.Text = "(" + CStr(culoare(0)) + ", " + CStr(culoare(1)) + ", " + CStr(culoare(2)) + ")"
        Return (culoare(0))
    End Function

    Function schimbaCuloare3(ByVal culoare As Object) As Double
        'Scimbare UI
        linkedin.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))

        'Schimbare paleta
        paleta3.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        RGB3.Text = "(" + CStr(culoare(0)) + ", " + CStr(culoare(1)) + ", " + CStr(culoare(2)) + ")"
        Return (culoare(0))
    End Function

    Function schimbaCuloare4(ByVal culoare As Object) As Double
        'Scimbare UI
        infos.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        textBG.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))

        'Schimbare paleta
        paleta4.BackColor = Color.FromArgb(culoare(0), culoare(1), culoare(2))
        RGB4.Text = "(" + CStr(culoare(0)) + ", " + CStr(culoare(1)) + ", " + CStr(culoare(2)) + ")"
        Return (culoare(0))
    End Function

    'Functii filtrare palete de culori ============================================================================================================
    Function verificarePaleta(ByVal paleta As List(Of String)) As Integer
        Dim verificare As Integer
        verificare = 0

        'verificare categorie
        If web.Checked = True Then
            If paleta(1) = "web" Then
                verificare = 1
            End If
        End If
        If brochure.Checked = True Then
            If paleta(1) = "brochure" Then
                verificare = 1
            End If
        End If
        If interior.Checked = True Then
            If paleta(1) = "interior" Then
                verificare = 1
            End If
        End If

        'verificare stiluri
        If Pastel.Checked = True Then
            If paleta(2) = "pastel" Then
                verificare = 1
            End If
        End If
        If Neon.Checked = True Then
            If paleta(2) = "neon" Then
                verificare = 1
            End If
        End If
        If Gold.Checked = True Then
            If paleta(2) = "gold" Then
                verificare = 1
            End If
        End If
        If Vintage.Checked = True Then
            If paleta(2) = "vintage" Then
                verificare = 1
            End If
        End If
        If Light.Checked = True Then
            If paleta(2) = "light" Then
                verificare = 1
            End If
        End If
        If Dark.Checked = True Then
            If paleta(2) = "dark" Then
                verificare = 1
            End If
        End If

        Return (verificare)
    End Function

    'buton generare paleta ============================================================================================================ 
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'creaza obiect cu toate paletele de culori
        Dim paleteCulori As New Dictionary(Of Integer, List(Of String))
        paleteCulori = crearePalete()

        'creaza obiect care va contine paletele filtrate
        Dim paleteFiltrate As New Dictionary(Of Integer, List(Of String))

        'verifica palete--------------------------------------------------------------------------------
        Dim confirmate As New List(Of String)
        confirmate.AddRange(New String() {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"})
        Dim verificat, contor, steps As Integer
        contor = 0

        For steps = 0 To 17
            'verificare paleta
            Dim paletaCurenta As New List(Of String)
            paletaCurenta = paleteCulori.Item(steps)
            verificat = verificarePaleta(paletaCurenta)

            'adaugare paleta in lista
            If verificat = 1 Then
                confirmate(contor) = paletaCurenta(0)
                contor = contor + 1

            End If
        Next

        'Generare random din cele confirmate -----------------------------------------------------------
        Dim Random, idFinal As Integer
        Random = (contor - 1) * Rnd() + 1
        idFinal = confirmate(Random)

        RichTextBox1.Text = idFinal.ToString

        Dim paletaFinala As New List(Of String)
        paletaFinala = paleteCulori.Item(idFinal)

        'Schimbare culoari
        Dim culoare1 As New List(Of Integer) From {paletaFinala(3), paletaFinala(4), paletaFinala(5)}
        schimbaCuloare1(culoare1)

        Dim culoare2 As New List(Of Integer) From {paletaFinala(6), paletaFinala(7), paletaFinala(8)}
        schimbaCuloare2(culoare2)

        Dim culoare3 As New List(Of Integer) From {paletaFinala(9), paletaFinala(10), paletaFinala(11)}
        schimbaCuloare3(culoare3)

        Dim culoare4 As New List(Of Integer) From {paletaFinala(12), paletaFinala(13), paletaFinala(14)}
        schimbaCuloare4(culoare4)

    End Sub


    'buton generare random ============================================================================================================ merge !!!
    Private Sub RandomBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RandomBtn.Click
        'creaza obiect cu toate paletele de culori
        Dim paleteCulori As New Dictionary(Of Integer, List(Of String))
        paleteCulori = crearePalete()

        Dim Random As Integer
        Random = Int(17 * Rnd() + 0)

        'Creaza obiect cu paleta finala
        Dim paletaFinala As New List(Of String)
        paletaFinala = paleteCulori.Item(Random)


        'Schimbare culoari
        Dim culoare1 As New List(Of Integer) From {paletaFinala(3), paletaFinala(4), paletaFinala(5)}
        schimbaCuloare1(culoare1)

        Dim culoare2 As New List(Of Integer) From {paletaFinala(6), paletaFinala(7), paletaFinala(8)}
        schimbaCuloare2(culoare2)

        Dim culoare3 As New List(Of Integer) From {paletaFinala(9), paletaFinala(10), paletaFinala(11)}
        schimbaCuloare3(culoare3)

        Dim culoare4 As New List(Of Integer) From {paletaFinala(12), paletaFinala(13), paletaFinala(14)}
        schimbaCuloare4(culoare4)


        RichTextBox2.Text = paletaFinala(0)
    End Sub

    'initiere formular ============================================================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'creare palete de culori
        

        'paleta generata 
        RGB.Font = New Font("Quicksand", 10, FontStyle.Bold)

        'Social Media section 
        facebook.FlatAppearance.BorderSize = 0
        twitter.FlatAppearance.BorderSize = 0
        linkedin.FlatAppearance.BorderSize = 0

        'Avatar section
        Avatar.FlatAppearance.BorderSize = 0
        AvatarName.Font = New Font("Quicksand", 18, FontStyle.Bold)
        AvatarRole.Font = New Font("Quicksand", 10, FontStyle.Regular)
        AvatarSocial.Font = New Font("Quicksand", 14, FontStyle.Bold)

        'Content section
        header.Font = New Font("Quicksand", 14, FontStyle.Bold)
        continut.Font = New Font("Quicksand", 10, FontStyle.Regular)
        infos.Font = New Font("Quicksand", 10, FontStyle.Regular)
    End Sub

    'Palete culori =================================================================================================================================================

    Function crearePalete() As Object
        Dim paleteCulori As New Dictionary(Of Integer, List(Of String))
        For i As Integer = 0 To 20
            paleteCulori.Add(i, New List(Of String))
        Next
        paleteCulori(0).AddRange(New String() {"0", "web", "pastel", "113", "111", "129", "185", "122", "149", "246", "174", "153", "242", "225", "193"})
        paleteCulori(1).AddRange(New String() {"1", "brochure", "pastel", "111", "76", "91", "158", "119", "119", "222", "186", "157", "245", "232", "199"})
        paleteCulori(2).AddRange(New String() {"2", "interior", "pastel", "95", "147", "154", "58", "99", "81", "160", "147", "125", "242", "257", "215"})

        paleteCulori(3).AddRange(New String() {"3", "web", "gold", "157", "92", "13", "229", "137", "10", "247", "208", "138", "250", "250", "250"})
        paleteCulori(4).AddRange(New String() {"4", "brochure", "gold", "226", "106", "44", "254", "130", "67", "253", "166", "93", "254", "208", "127"})
        paleteCulori(5).AddRange(New String() {"5", "interior", "gold", "74", "64", "58", "164", "93", "93", "254", "192", "105", "239", "239", "239"})

        paleteCulori(6).AddRange(New String() {"6", "web", "neon", "254", "1", "117", "23", "39", "116", "119", "217", "112", "238", "238", "238"})
        paleteCulori(7).AddRange(New String() {"7", "brochure", "neon", "59", "1", "1", "254", "1", "1", "254", "149", "197", "254", "246", "205"})
        paleteCulori(8).AddRange(New String() {"8", "interior", "neon", "72", "1", "50", "1", "87", "146", "252", "146", "227", "242", "244", "195"})

        paleteCulori(9).AddRange(New String() {"9", "web", "vintage", "1", "1", "1", "189", "75", "75", "239", "183", "183", "238", "238", "238"})
        paleteCulori(10).AddRange(New String() {"10", "brochure", "vintage", "125", "90", "80", "180", "132", "108", "229", "178", "153", "252", "222", "192"})
        paleteCulori(11).AddRange(New String() {"11", "interior", "vintage", "47", "93", "98", "94", "139", "126", "167", "196", "188", "223", "238", "234"})

        paleteCulori(12).AddRange(New String() {"12", "web", "light", "144", "127", "164", "165", "143", "170", "166", "214", "214", "237", "237", "208"})
        paleteCulori(13).AddRange(New String() {"13", "brochure", "light", "85", "117", "113", "212", "154", "137", "247", "209", "186", "244", "244", "244"})
        paleteCulori(14).AddRange(New String() {"14", "interior", "light", "125", "90", "90", "241", "209", "209", "243", "225", "225", "250", "242", "242"})

        paleteCulori(15).AddRange(New String() {"15", "web", "dark", "25", "26", "25", "30", "81", "40", "78", "159", "61", "216", "233", "168"})
        paleteCulori(16).AddRange(New String() {"16", "brochure", "dark", "45", "36", "36", "92", "61", "46", "184", "93", "56", "224", "192", "151"})
        paleteCulori(17).AddRange(New String() {"17", "interior", "dark", "15", "4", "76", "20", "30", "97", "120", "122", "145", "238", "238", "238"})



        Return paleteCulori
    End Function

    
End Class
