﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Dark = New System.Windows.Forms.CheckBox()
        Me.Light = New System.Windows.Forms.CheckBox()
        Me.Vintage = New System.Windows.Forms.CheckBox()
        Me.Gold = New System.Windows.Forms.CheckBox()
        Me.Neon = New System.Windows.Forms.CheckBox()
        Me.Pastel = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.interior = New System.Windows.Forms.CheckBox()
        Me.web = New System.Windows.Forms.CheckBox()
        Me.brochure = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RandomZone = New System.Windows.Forms.GroupBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RandomBtn = New System.Windows.Forms.Button()
        Me.PaletaGenerata = New System.Windows.Forms.GroupBox()
        Me.RGB4 = New System.Windows.Forms.Label()
        Me.RGB3 = New System.Windows.Forms.Label()
        Me.RGB2 = New System.Windows.Forms.Label()
        Me.RGB1 = New System.Windows.Forms.Label()
        Me.RGB = New System.Windows.Forms.Label()
        Me.paleta4 = New System.Windows.Forms.Button()
        Me.paleta3 = New System.Windows.Forms.Button()
        Me.paleta2 = New System.Windows.Forms.Button()
        Me.paleta1 = New System.Windows.Forms.Button()
        Me.LiveDemo = New System.Windows.Forms.GroupBox()
        Me.infos = New System.Windows.Forms.RichTextBox()
        Me.textBG = New System.Windows.Forms.RichTextBox()
        Me.btn_filled = New System.Windows.Forms.Button()
        Me.btn_empty = New System.Windows.Forms.Button()
        Me.continut = New System.Windows.Forms.RichTextBox()
        Me.header = New System.Windows.Forms.Label()
        Me.linkedin = New System.Windows.Forms.Button()
        Me.twitter = New System.Windows.Forms.Button()
        Me.facebook = New System.Windows.Forms.Button()
        Me.AvatarSocial = New System.Windows.Forms.Label()
        Me.AvatarRole = New System.Windows.Forms.Label()
        Me.AvatarName = New System.Windows.Forms.Label()
        Me.Avatar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.RandomZone.SuspendLayout()
        Me.PaletaGenerata.SuspendLayout()
        Me.LiveDemo.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RichTextBox1)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Dark)
        Me.GroupBox1.Controls.Add(Me.Light)
        Me.GroupBox1.Controls.Add(Me.Vintage)
        Me.GroupBox1.Controls.Add(Me.Gold)
        Me.GroupBox1.Controls.Add(Me.Neon)
        Me.GroupBox1.Controls.Add(Me.Pastel)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.interior)
        Me.GroupBox1.Controls.Add(Me.web)
        Me.GroupBox1.Controls.Add(Me.brochure)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(363, 304)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Panou principal"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.White
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.ForeColor = System.Drawing.SystemColors.GrayText
        Me.RichTextBox1.Location = New System.Drawing.Point(183, 233)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(153, 40)
        Me.RichTextBox1.TabIndex = 18
        Me.RichTextBox1.Text = "Apăsați din nou butonul pentru o altă paletă de culoare cu aceleași specificații." & _
            ""
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.SandyBrown
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(18, 228)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(159, 50)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Genereaza"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Dark
        '
        Me.Dark.AutoSize = True
        Me.Dark.Location = New System.Drawing.Point(125, 138)
        Me.Dark.Name = "Dark"
        Me.Dark.Size = New System.Drawing.Size(49, 17)
        Me.Dark.TabIndex = 12
        Me.Dark.Text = "Dark"
        Me.Dark.UseVisualStyleBackColor = True
        '
        'Light
        '
        Me.Light.AutoSize = True
        Me.Light.Location = New System.Drawing.Point(252, 138)
        Me.Light.Name = "Light"
        Me.Light.Size = New System.Drawing.Size(49, 17)
        Me.Light.TabIndex = 11
        Me.Light.Text = "Light"
        Me.Light.UseVisualStyleBackColor = True
        '
        'Vintage
        '
        Me.Vintage.AutoSize = True
        Me.Vintage.Location = New System.Drawing.Point(18, 138)
        Me.Vintage.Name = "Vintage"
        Me.Vintage.Size = New System.Drawing.Size(62, 17)
        Me.Vintage.TabIndex = 9
        Me.Vintage.Text = "Vintage"
        Me.Vintage.UseVisualStyleBackColor = True
        '
        'Gold
        '
        Me.Gold.AutoSize = True
        Me.Gold.Location = New System.Drawing.Point(252, 109)
        Me.Gold.Name = "Gold"
        Me.Gold.Size = New System.Drawing.Size(48, 17)
        Me.Gold.TabIndex = 8
        Me.Gold.Text = "Gold"
        Me.Gold.UseVisualStyleBackColor = True
        '
        'Neon
        '
        Me.Neon.AutoSize = True
        Me.Neon.Location = New System.Drawing.Point(125, 109)
        Me.Neon.Name = "Neon"
        Me.Neon.Size = New System.Drawing.Size(52, 17)
        Me.Neon.TabIndex = 7
        Me.Neon.Text = "Neon"
        Me.Neon.UseVisualStyleBackColor = True
        '
        'Pastel
        '
        Me.Pastel.AutoSize = True
        Me.Pastel.Location = New System.Drawing.Point(18, 109)
        Me.Pastel.Name = "Pastel"
        Me.Pastel.Size = New System.Drawing.Size(55, 17)
        Me.Pastel.TabIndex = 6
        Me.Pastel.Text = "Pastel"
        Me.Pastel.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 84)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Stiluri"
        '
        'interior
        '
        Me.interior.AutoSize = True
        Me.interior.Location = New System.Drawing.Point(252, 55)
        Me.interior.Name = "interior"
        Me.interior.Size = New System.Drawing.Size(94, 17)
        Me.interior.TabIndex = 4
        Me.interior.Text = "Design Interior"
        Me.interior.UseVisualStyleBackColor = True
        '
        'web
        '
        Me.web.AutoSize = True
        Me.web.Location = New System.Drawing.Point(18, 55)
        Me.web.Name = "web"
        Me.web.Size = New System.Drawing.Size(85, 17)
        Me.web.TabIndex = 3
        Me.web.Text = "Web Design"
        Me.web.UseVisualStyleBackColor = True
        '
        'brochure
        '
        Me.brochure.AutoSize = True
        Me.brochure.Location = New System.Drawing.Point(125, 55)
        Me.brochure.Name = "brochure"
        Me.brochure.Size = New System.Drawing.Size(105, 17)
        Me.brochure.TabIndex = 2
        Me.brochure.Text = "Brochure Design"
        Me.brochure.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Alegeți categorie"
        '
        'RandomZone
        '
        Me.RandomZone.Controls.Add(Me.RichTextBox2)
        Me.RandomZone.Controls.Add(Me.RandomBtn)
        Me.RandomZone.Location = New System.Drawing.Point(12, 352)
        Me.RandomZone.Name = "RandomZone"
        Me.RandomZone.Size = New System.Drawing.Size(363, 84)
        Me.RandomZone.TabIndex = 1
        Me.RandomZone.TabStop = False
        Me.RandomZone.Text = "Random Zone"
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox2.ForeColor = System.Drawing.SystemColors.GrayText
        Me.RichTextBox2.Location = New System.Drawing.Point(183, 24)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(139, 40)
        Me.RichTextBox2.TabIndex = 19
        Me.RichTextBox2.Text = "Folosirea functiei random va sterge datele din formularul de mai sus!"
        '
        'RandomBtn
        '
        Me.RandomBtn.BackColor = System.Drawing.Color.LimeGreen
        Me.RandomBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RandomBtn.ForeColor = System.Drawing.Color.White
        Me.RandomBtn.Location = New System.Drawing.Point(18, 19)
        Me.RandomBtn.Name = "RandomBtn"
        Me.RandomBtn.Size = New System.Drawing.Size(159, 50)
        Me.RandomBtn.TabIndex = 0
        Me.RandomBtn.Text = "Random"
        Me.RandomBtn.UseVisualStyleBackColor = False
        '
        'PaletaGenerata
        '
        Me.PaletaGenerata.Controls.Add(Me.RGB4)
        Me.PaletaGenerata.Controls.Add(Me.RGB3)
        Me.PaletaGenerata.Controls.Add(Me.RGB2)
        Me.PaletaGenerata.Controls.Add(Me.RGB1)
        Me.PaletaGenerata.Controls.Add(Me.RGB)
        Me.PaletaGenerata.Controls.Add(Me.paleta4)
        Me.PaletaGenerata.Controls.Add(Me.paleta3)
        Me.PaletaGenerata.Controls.Add(Me.paleta2)
        Me.PaletaGenerata.Controls.Add(Me.paleta1)
        Me.PaletaGenerata.Location = New System.Drawing.Point(12, 473)
        Me.PaletaGenerata.Name = "PaletaGenerata"
        Me.PaletaGenerata.Size = New System.Drawing.Size(363, 212)
        Me.PaletaGenerata.TabIndex = 2
        Me.PaletaGenerata.TabStop = False
        Me.PaletaGenerata.Text = "Paleta de culori generata"
        '
        'RGB4
        '
        Me.RGB4.AutoSize = True
        Me.RGB4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.RGB4.Location = New System.Drawing.Point(271, 180)
        Me.RGB4.Name = "RGB4"
        Me.RGB4.Size = New System.Drawing.Size(28, 13)
        Me.RGB4.TabIndex = 8
        Me.RGB4.Text = "rgb4"
        '
        'RGB3
        '
        Me.RGB3.AutoSize = True
        Me.RGB3.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.RGB3.Location = New System.Drawing.Point(187, 180)
        Me.RGB3.Name = "RGB3"
        Me.RGB3.Size = New System.Drawing.Size(28, 13)
        Me.RGB3.TabIndex = 7
        Me.RGB3.Text = "rgb3"
        '
        'RGB2
        '
        Me.RGB2.AutoSize = True
        Me.RGB2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.RGB2.Location = New System.Drawing.Point(103, 180)
        Me.RGB2.Name = "RGB2"
        Me.RGB2.Size = New System.Drawing.Size(28, 13)
        Me.RGB2.TabIndex = 6
        Me.RGB2.Text = "rgb2"
        '
        'RGB1
        '
        Me.RGB1.AutoSize = True
        Me.RGB1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.RGB1.Location = New System.Drawing.Point(16, 180)
        Me.RGB1.Name = "RGB1"
        Me.RGB1.Size = New System.Drawing.Size(28, 13)
        Me.RGB1.TabIndex = 5
        Me.RGB1.Text = "rgb1"
        '
        'RGB
        '
        Me.RGB.AutoSize = True
        Me.RGB.Location = New System.Drawing.Point(16, 152)
        Me.RGB.Name = "RGB"
        Me.RGB.Size = New System.Drawing.Size(30, 13)
        Me.RGB.TabIndex = 4
        Me.RGB.Text = "RGB"
        '
        'paleta4
        '
        Me.paleta4.BackColor = System.Drawing.Color.Gainsboro
        Me.paleta4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.paleta4.Location = New System.Drawing.Point(273, 29)
        Me.paleta4.Name = "paleta4"
        Me.paleta4.Size = New System.Drawing.Size(72, 100)
        Me.paleta4.TabIndex = 3
        Me.paleta4.UseVisualStyleBackColor = False
        '
        'paleta3
        '
        Me.paleta3.BackColor = System.Drawing.Color.Gainsboro
        Me.paleta3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.paleta3.Location = New System.Drawing.Point(189, 29)
        Me.paleta3.Name = "paleta3"
        Me.paleta3.Size = New System.Drawing.Size(72, 100)
        Me.paleta3.TabIndex = 2
        Me.paleta3.UseVisualStyleBackColor = False
        '
        'paleta2
        '
        Me.paleta2.BackColor = System.Drawing.Color.Gainsboro
        Me.paleta2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.paleta2.Location = New System.Drawing.Point(105, 29)
        Me.paleta2.Name = "paleta2"
        Me.paleta2.Size = New System.Drawing.Size(72, 100)
        Me.paleta2.TabIndex = 1
        Me.paleta2.UseVisualStyleBackColor = False
        '
        'paleta1
        '
        Me.paleta1.BackColor = System.Drawing.Color.Gainsboro
        Me.paleta1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.paleta1.Location = New System.Drawing.Point(19, 29)
        Me.paleta1.Name = "paleta1"
        Me.paleta1.Size = New System.Drawing.Size(74, 100)
        Me.paleta1.TabIndex = 0
        Me.paleta1.UseVisualStyleBackColor = False
        '
        'LiveDemo
        '
        Me.LiveDemo.Controls.Add(Me.infos)
        Me.LiveDemo.Controls.Add(Me.textBG)
        Me.LiveDemo.Controls.Add(Me.btn_filled)
        Me.LiveDemo.Controls.Add(Me.btn_empty)
        Me.LiveDemo.Controls.Add(Me.continut)
        Me.LiveDemo.Controls.Add(Me.header)
        Me.LiveDemo.Controls.Add(Me.linkedin)
        Me.LiveDemo.Controls.Add(Me.twitter)
        Me.LiveDemo.Controls.Add(Me.facebook)
        Me.LiveDemo.Controls.Add(Me.AvatarSocial)
        Me.LiveDemo.Controls.Add(Me.AvatarRole)
        Me.LiveDemo.Controls.Add(Me.AvatarName)
        Me.LiveDemo.Controls.Add(Me.Avatar)
        Me.LiveDemo.Location = New System.Drawing.Point(393, 12)
        Me.LiveDemo.Name = "LiveDemo"
        Me.LiveDemo.Size = New System.Drawing.Size(386, 673)
        Me.LiveDemo.TabIndex = 3
        Me.LiveDemo.TabStop = False
        Me.LiveDemo.Text = "LIVE UI KIT DEMO"
        '
        'infos
        '
        Me.infos.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.infos.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.infos.Location = New System.Drawing.Point(36, 353)
        Me.infos.Name = "infos"
        Me.infos.Size = New System.Drawing.Size(301, 78)
        Me.infos.TabIndex = 12
        Me.infos.Text = "Două aspecte importante ale marketingului sunt recrutarea de noi clienți (achiziț" & _
            "ie) și menținerea/impulsionarea relațiilor cu clienții existenți (administrarea " & _
            "bazei de clienți)."
        '
        'textBG
        '
        Me.textBG.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.textBG.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.textBG.Location = New System.Drawing.Point(20, 337)
        Me.textBG.Name = "textBG"
        Me.textBG.Size = New System.Drawing.Size(338, 111)
        Me.textBG.TabIndex = 13
        Me.textBG.Text = ""
        '
        'btn_filled
        '
        Me.btn_filled.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_filled.Location = New System.Drawing.Point(199, 467)
        Me.btn_filled.Name = "btn_filled"
        Me.btn_filled.Size = New System.Drawing.Size(159, 50)
        Me.btn_filled.TabIndex = 10
        Me.btn_filled.Text = "Viziteaza site"
        Me.btn_filled.UseVisualStyleBackColor = True
        '
        'btn_empty
        '
        Me.btn_empty.BackColor = System.Drawing.Color.DimGray
        Me.btn_empty.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_empty.ForeColor = System.Drawing.Color.White
        Me.btn_empty.Location = New System.Drawing.Point(20, 467)
        Me.btn_empty.Name = "btn_empty"
        Me.btn_empty.Size = New System.Drawing.Size(159, 50)
        Me.btn_empty.TabIndex = 9
        Me.btn_empty.Text = "Vezi mai mult"
        Me.btn_empty.UseVisualStyleBackColor = False
        '
        'continut
        '
        Me.continut.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.continut.Location = New System.Drawing.Point(23, 224)
        Me.continut.Name = "continut"
        Me.continut.Size = New System.Drawing.Size(338, 80)
        Me.continut.TabIndex = 8
        Me.continut.Text = """Marketingul este un proces permanent prin care oamenii sunt încurajați să ia o d" & _
            "ecizie de cumpărare, de folosire, de urmare sau de conformare a unui produs, ser" & _
            "viciu sau valori ale altei persoane."""
        '
        'header
        '
        Me.header.AutoSize = True
        Me.header.Location = New System.Drawing.Point(20, 195)
        Me.header.Name = "header"
        Me.header.Size = New System.Drawing.Size(69, 13)
        Me.header.TabIndex = 7
        Me.header.Text = "Titlu principal"
        '
        'linkedin
        '
        Me.linkedin.BackColor = System.Drawing.Color.Black
        Me.linkedin.BackgroundImage = CType(resources.GetObject("linkedin.BackgroundImage"), System.Drawing.Image)
        Me.linkedin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.linkedin.Location = New System.Drawing.Point(134, 618)
        Me.linkedin.Name = "linkedin"
        Me.linkedin.Size = New System.Drawing.Size(37, 36)
        Me.linkedin.TabIndex = 6
        Me.linkedin.UseVisualStyleBackColor = False
        '
        'twitter
        '
        Me.twitter.BackColor = System.Drawing.Color.SkyBlue
        Me.twitter.BackgroundImage = CType(resources.GetObject("twitter.BackgroundImage"), System.Drawing.Image)
        Me.twitter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.twitter.Location = New System.Drawing.Point(77, 618)
        Me.twitter.Name = "twitter"
        Me.twitter.Size = New System.Drawing.Size(37, 36)
        Me.twitter.TabIndex = 5
        Me.twitter.UseVisualStyleBackColor = False
        '
        'facebook
        '
        Me.facebook.BackColor = System.Drawing.Color.DarkTurquoise
        Me.facebook.BackgroundImage = CType(resources.GetObject("facebook.BackgroundImage"), System.Drawing.Image)
        Me.facebook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.facebook.Location = New System.Drawing.Point(20, 618)
        Me.facebook.Name = "facebook"
        Me.facebook.Size = New System.Drawing.Size(37, 36)
        Me.facebook.TabIndex = 4
        Me.facebook.UseVisualStyleBackColor = False
        '
        'AvatarSocial
        '
        Me.AvatarSocial.AutoSize = True
        Me.AvatarSocial.Location = New System.Drawing.Point(17, 577)
        Me.AvatarSocial.Name = "AvatarSocial"
        Me.AvatarSocial.Size = New System.Drawing.Size(68, 13)
        Me.AvatarSocial.TabIndex = 3
        Me.AvatarSocial.Text = "Social Media"
        '
        'AvatarRole
        '
        Me.AvatarRole.AutoSize = True
        Me.AvatarRole.Location = New System.Drawing.Point(178, 138)
        Me.AvatarRole.Name = "AvatarRole"
        Me.AvatarRole.Size = New System.Drawing.Size(95, 13)
        Me.AvatarRole.TabIndex = 2
        Me.AvatarRole.Text = "Co-Founder ARCO"
        '
        'AvatarName
        '
        Me.AvatarName.AutoSize = True
        Me.AvatarName.Location = New System.Drawing.Point(178, 107)
        Me.AvatarName.Name = "AvatarName"
        Me.AvatarName.Size = New System.Drawing.Size(70, 13)
        Me.AvatarName.TabIndex = 1
        Me.AvatarName.Text = "Adam Nelson"
        '
        'Avatar
        '
        Me.Avatar.BackColor = System.Drawing.Color.Transparent
        Me.Avatar.BackgroundImage = CType(resources.GetObject("Avatar.BackgroundImage"), System.Drawing.Image)
        Me.Avatar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Avatar.Location = New System.Drawing.Point(23, 30)
        Me.Avatar.Name = "Avatar"
        Me.Avatar.Size = New System.Drawing.Size(131, 129)
        Me.Avatar.TabIndex = 0
        Me.Avatar.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(791, 697)
        Me.Controls.Add(Me.LiveDemo)
        Me.Controls.Add(Me.PaletaGenerata)
        Me.Controls.Add(Me.RandomZone)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.RandomZone.ResumeLayout(False)
        Me.PaletaGenerata.ResumeLayout(False)
        Me.PaletaGenerata.PerformLayout()
        Me.LiveDemo.ResumeLayout(False)
        Me.LiveDemo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Dark As System.Windows.Forms.CheckBox
    Friend WithEvents Light As System.Windows.Forms.CheckBox
    Friend WithEvents Vintage As System.Windows.Forms.CheckBox
    Friend WithEvents Gold As System.Windows.Forms.CheckBox
    Friend WithEvents Neon As System.Windows.Forms.CheckBox
    Friend WithEvents Pastel As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents interior As System.Windows.Forms.CheckBox
    Friend WithEvents web As System.Windows.Forms.CheckBox
    Friend WithEvents brochure As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RandomZone As System.Windows.Forms.GroupBox
    Friend WithEvents RandomBtn As System.Windows.Forms.Button
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents PaletaGenerata As System.Windows.Forms.GroupBox
    Friend WithEvents RGB4 As System.Windows.Forms.Label
    Friend WithEvents RGB3 As System.Windows.Forms.Label
    Friend WithEvents RGB2 As System.Windows.Forms.Label
    Friend WithEvents RGB1 As System.Windows.Forms.Label
    Friend WithEvents RGB As System.Windows.Forms.Label
    Friend WithEvents paleta4 As System.Windows.Forms.Button
    Friend WithEvents paleta3 As System.Windows.Forms.Button
    Friend WithEvents paleta2 As System.Windows.Forms.Button
    Friend WithEvents paleta1 As System.Windows.Forms.Button
    Friend WithEvents LiveDemo As System.Windows.Forms.GroupBox
    Friend WithEvents Avatar As System.Windows.Forms.Button
    Friend WithEvents AvatarName As System.Windows.Forms.Label
    Friend WithEvents AvatarRole As System.Windows.Forms.Label
    Friend WithEvents AvatarSocial As System.Windows.Forms.Label
    Friend WithEvents facebook As System.Windows.Forms.Button
    Friend WithEvents twitter As System.Windows.Forms.Button
    Friend WithEvents linkedin As System.Windows.Forms.Button
    Friend WithEvents header As System.Windows.Forms.Label
    Friend WithEvents continut As System.Windows.Forms.RichTextBox
    Friend WithEvents btn_filled As System.Windows.Forms.Button
    Friend WithEvents btn_empty As System.Windows.Forms.Button
    Friend WithEvents infos As System.Windows.Forms.RichTextBox
    Friend WithEvents textBG As System.Windows.Forms.RichTextBox

End Class
